#pragma once
#include <atomic>
#include <memory>
#include <thread>

#include "attestor.h"
#include "config.h"
#include "svid_store.h"
#include "workload_api.h"

namespace spire_agent {

// Agent ties everything together:
//   1. Runs x509pop attestation against the SPIRE server.
//   2. Starts the Workload API server so local workloads can fetch SVIDs.
//   3. Runs a renewal loop that re-keys the agent SVID before expiry.
class Agent {
public:
    explicit Agent(const Config& cfg);

    // Blocks until stop() is called or a fatal error occurs.
    void run();

    void stop();

private:
    Config                           cfg_;
    SVIDStore                        store_;
    std::unique_ptr<X509PopAttestor> attestor_;
    std::unique_ptr<WorkloadAPIServer> workload_server_;

    std::atomic<bool> running_{false};
    std::thread       renewal_thread_;

    void renewal_loop();
};

} // namespace spire_agent
