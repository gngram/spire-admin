#pragma once
#include <chrono>
#include <ctime>
#include <iostream>
#include <sstream>
#include <string>

namespace spire_agent {

enum class LogLevel { DEBUG, INFO, WARN, ERROR };

class Logger {
public:
    static Logger& instance() {
        static Logger inst;
        return inst;
    }

    void set_level(LogLevel l) { level_ = l; }

    void log(LogLevel l, const std::string& component, const std::string& msg) {
        if (l < level_) return;
        auto now = std::chrono::system_clock::now();
        auto t   = std::chrono::system_clock::to_time_t(now);
        char buf[32];
        std::strftime(buf, sizeof(buf), "%Y-%m-%dT%H:%M:%S", std::localtime(&t));
        std::ostream& out = (l >= LogLevel::WARN) ? std::cerr : std::cout;
        out << buf << " [" << level_str(l) << "] [" << component << "] " << msg << "\n";
    }

private:
    LogLevel level_ = LogLevel::INFO;

    static const char* level_str(LogLevel l) {
        switch (l) {
            case LogLevel::DEBUG: return "DEBUG";
            case LogLevel::INFO:  return "INFO ";
            case LogLevel::WARN:  return "WARN ";
            case LogLevel::ERROR: return "ERROR";
        }
        return "?";
    }
};

#define LOG_DEBUG(comp, msg) \
    spire_agent::Logger::instance().log(spire_agent::LogLevel::DEBUG, comp, msg)
#define LOG_INFO(comp, msg) \
    spire_agent::Logger::instance().log(spire_agent::LogLevel::INFO, comp, msg)
#define LOG_WARN(comp, msg) \
    spire_agent::Logger::instance().log(spire_agent::LogLevel::WARN, comp, msg)
#define LOG_ERROR(comp, msg) \
    spire_agent::Logger::instance().log(spire_agent::LogLevel::ERROR, comp, msg)

} // namespace spire_agent
