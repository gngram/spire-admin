#pragma once
#include <atomic>
#include <memory>
#include <string>
#include <thread>

#include <grpcpp/grpcpp.h>

#include "config.h"
#include "logger.h"
#include "svid_store.h"

// Generated protobuf headers (included after build)
#include "spiffe/workload.grpc.pb.h"
#include "spiffe/workload.pb.h"

namespace spire_agent {

// WorkloadAPIServer exposes the SPIFFE Workload API on a Unix domain socket.
// Workloads call FetchX509SVID / FetchX509Bundles to get their SVIDs.
//
// This implementation:
//   - Serves FetchX509SVID as a server-streaming RPC; sends the current SVID
//     once, then sends an update whenever SVIDStore::notify_update() is called.
//   - Serves FetchX509Bundles similarly.
//   - Does NOT perform workload attestation — it trusts any caller on the
//     Unix socket (production agents add unix peer UID/GID checks here).
class WorkloadAPIServer final
    : public spiffe::workload::SpiffeWorkloadAPI::Service {
public:
    WorkloadAPIServer(const Config& cfg, SVIDStore& store)
        : cfg_(cfg), store_(store) {}

    // Start the gRPC server in a background thread.
    void start();

    // Graceful shutdown.
    void stop();

    // ── SpiffeWorkloadAPI::Service overrides ─────────────────────────────────

    grpc::Status FetchX509SVID(
        grpc::ServerContext* ctx,
        const spiffe::workload::X509SVIDRequest* req,
        grpc::ServerWriter<spiffe::workload::X509SVIDResponse>* writer) override;

    grpc::Status FetchX509Bundles(
        grpc::ServerContext* ctx,
        const spiffe::workload::X509BundlesRequest* req,
        grpc::ServerWriter<spiffe::workload::X509BundlesResponse>* writer) override;

    // Minimal stubs for JWT (not implemented — x509pop agent is X.509 only)
    grpc::Status FetchJWTSVID(
        grpc::ServerContext* ctx,
        const spiffe::workload::JWTSVIDRequest* req,
        spiffe::workload::JWTSVIDResponse* resp) override {
        return grpc::Status(grpc::StatusCode::UNIMPLEMENTED,
                            "JWT SVIDs not supported by this agent");
    }

    grpc::Status FetchJWTBundles(
        grpc::ServerContext* ctx,
        const spiffe::workload::JWTBundlesRequest* req,
        grpc::ServerWriter<spiffe::workload::JWTBundlesResponse>* writer) override {
        return grpc::Status(grpc::StatusCode::UNIMPLEMENTED,
                            "JWT bundles not supported by this agent");
    }

    grpc::Status ValidateJWTSVID(
        grpc::ServerContext* ctx,
        const spiffe::workload::ValidateJWTSVIDRequest* req,
        spiffe::workload::ValidateJWTSVIDResponse* resp) override {
        return grpc::Status(grpc::StatusCode::UNIMPLEMENTED,
                            "JWT validation not supported by this agent");
    }

private:
    const Config&              cfg_;
    SVIDStore&                 store_;
    std::unique_ptr<grpc::Server> server_;
    std::thread                server_thread_;

    // Build a single X509SVIDResponse from the current store state.
    spiffe::workload::X509SVIDResponse build_svid_response() const;

    // Build a single X509BundlesResponse from the current store state.
    spiffe::workload::X509BundlesResponse build_bundles_response() const;
};

} // namespace spire_agent
