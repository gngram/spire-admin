#pragma once
#include <string>

namespace spire_agent {

struct Config {
    // SPIRE Server address, e.g. "localhost:8081"
    std::string server_address;

    // Trust domain, e.g. "example.org"
    std::string trust_domain;

    // Path to the agent's attesting certificate (PEM)
    std::string x509pop_cert_path;

    // Path to the agent's attesting private key (PEM)
    std::string x509pop_key_path;

    // Unix socket path where the Workload API will be served
    // e.g. "/tmp/spire-agent/public/api.sock"
    std::string workload_api_socket;

    // Directory for persisting agent state (bundle, SVID)
    std::string data_dir;

    // How many seconds before SVID expiry to trigger renewal (default 30s)
    int renew_before_seconds = 30;
};

} // namespace spire_agent
