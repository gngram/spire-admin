#pragma once
#include <mutex>
#include <string>
#include <vector>
#include <chrono>
#include <functional>

namespace spire_agent {

// Holds one X.509 SVID fetched from the SPIRE server.
struct SVID {
    std::string spiffe_id;

    // DER-encoded cert chain (agent SVID cert + any intermediates)
    std::vector<std::vector<uint8_t>> cert_chain;

    // DER-encoded private key (PKCS#8)
    std::vector<uint8_t> private_key_der;

    // Expiry as Unix timestamp (seconds)
    int64_t expires_at = 0;

    bool valid() const {
        auto now = std::chrono::system_clock::now();
        auto ts  = std::chrono::duration_cast<std::chrono::seconds>(
                       now.time_since_epoch()).count();
        return expires_at > ts;
    }

    // Seconds until expiry (negative if already expired)
    int64_t seconds_until_expiry() const {
        auto now = std::chrono::system_clock::now();
        auto ts  = std::chrono::duration_cast<std::chrono::seconds>(
                       now.time_since_epoch()).count();
        return expires_at - ts;
    }
};

// Holds the trust bundle (root CA certs) for the trust domain.
struct Bundle {
    std::string trust_domain;
    std::vector<std::vector<uint8_t>> x509_authorities; // DER-encoded roots
};

// Thread-safe store for the current SVID + bundle.
// The WorkloadAPI and the renewal loop both access this concurrently.
class SVIDStore {
public:
    void set_svid(const SVID& svid) {
        std::lock_guard<std::mutex> lk(mu_);
        svid_    = svid;
        has_svid_ = true;
    }

    // Returns a copy; empty SVID if not yet populated.
    SVID get_svid() const {
        std::lock_guard<std::mutex> lk(mu_);
        return svid_;
    }

    bool has_svid() const {
        std::lock_guard<std::mutex> lk(mu_);
        return has_svid_;
    }

    void set_bundle(const Bundle& b) {
        std::lock_guard<std::mutex> lk(mu_);
        bundle_     = b;
        has_bundle_ = true;
    }

    Bundle get_bundle() const {
        std::lock_guard<std::mutex> lk(mu_);
        return bundle_;
    }

    bool has_bundle() const {
        std::lock_guard<std::mutex> lk(mu_);
        return has_bundle_;
    }

    // Register a callback invoked (under no lock) when the SVID changes.
    // Used by the Workload API server to push updates to subscribers.
    void on_update(std::function<void()> cb) {
        std::lock_guard<std::mutex> lk(mu_);
        callbacks_.push_back(std::move(cb));
    }

    void notify_update() {
        std::vector<std::function<void()>> cbs;
        {
            std::lock_guard<std::mutex> lk(mu_);
            cbs = callbacks_;
        }
        for (auto& cb : cbs) cb();
    }

private:
    mutable std::mutex mu_;
    SVID               svid_;
    Bundle             bundle_;
    bool               has_svid_   = false;
    bool               has_bundle_ = false;
    std::vector<std::function<void()>> callbacks_;
};

} // namespace spire_agent
