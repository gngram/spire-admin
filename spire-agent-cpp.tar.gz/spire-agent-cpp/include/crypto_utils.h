#pragma once
#include <stdexcept>
#include <string>
#include <vector>

#include <openssl/err.h>
#include <openssl/evp.h>
#include <openssl/pem.h>
#include <openssl/rsa.h>
#include <openssl/x509.h>
#include <openssl/x509v3.h>

namespace spire_agent {
namespace crypto {

// ── RAII wrappers ─────────────────────────────────────────────────────────────

struct EVP_PKEY_Deleter { void operator()(EVP_PKEY* p) { EVP_PKEY_free(p); } };
struct X509_Deleter     { void operator()(X509* p)     { X509_free(p); } };
struct X509_REQ_Deleter { void operator()(X509_REQ* p) { X509_REQ_free(p); } };
struct BIO_Deleter      { void operator()(BIO* p)      { BIO_free_all(p); } };

using EVP_PKEY_ptr = std::unique_ptr<EVP_PKEY, EVP_PKEY_Deleter>;
using X509_ptr     = std::unique_ptr<X509,     X509_Deleter>;
using X509_REQ_ptr = std::unique_ptr<X509_REQ, X509_REQ_Deleter>;
using BIO_ptr      = std::unique_ptr<BIO,      BIO_Deleter>;

// ── Helpers ───────────────────────────────────────────────────────────────────

inline std::string openssl_error() {
    BIO_ptr bio(BIO_new(BIO_s_mem()));
    ERR_print_errors(bio.get());
    char* buf = nullptr;
    long len  = BIO_get_mem_data(bio.get(), &buf);
    return std::string(buf, len);
}

// Load a PEM private key from file.
inline EVP_PKEY_ptr load_private_key(const std::string& path) {
    BIO_ptr bio(BIO_new_file(path.c_str(), "r"));
    if (!bio) throw std::runtime_error("Cannot open key file: " + path);
    EVP_PKEY* key = PEM_read_bio_PrivateKey(bio.get(), nullptr, nullptr, nullptr);
    if (!key) throw std::runtime_error("Failed to read private key: " + openssl_error());
    return EVP_PKEY_ptr(key);
}

// Load a PEM certificate from file, return as DER bytes.
inline std::vector<uint8_t> load_cert_der(const std::string& path) {
    BIO_ptr bio(BIO_new_file(path.c_str(), "r"));
    if (!bio) throw std::runtime_error("Cannot open cert file: " + path);
    X509_ptr cert(PEM_read_bio_X509(bio.get(), nullptr, nullptr, nullptr));
    if (!cert) throw std::runtime_error("Failed to read certificate: " + openssl_error());

    unsigned char* der = nullptr;
    int len = i2d_X509(cert.get(), &der);
    if (len < 0) throw std::runtime_error("DER encode failed: " + openssl_error());
    std::vector<uint8_t> out(der, der + len);
    OPENSSL_free(der);
    return out;
}

// Load a PEM certificate from file, return the X509 object.
inline X509_ptr load_cert(const std::string& path) {
    BIO_ptr bio(BIO_new_file(path.c_str(), "r"));
    if (!bio) throw std::runtime_error("Cannot open cert file: " + path);
    X509* cert = PEM_read_bio_X509(bio.get(), nullptr, nullptr, nullptr);
    if (!cert) throw std::runtime_error("Failed to read certificate: " + openssl_error());
    return X509_ptr(cert);
}

// Generate a fresh RSA-2048 key pair.
inline EVP_PKEY_ptr generate_key() {
    EVP_PKEY_ptr pkey(EVP_PKEY_new());
    EVP_PKEY_CTX* ctx = EVP_PKEY_CTX_new_id(EVP_PKEY_RSA, nullptr);
    if (!ctx) throw std::runtime_error("EVP_PKEY_CTX_new_id failed");
    EVP_PKEY_keygen_init(ctx);
    EVP_PKEY_CTX_set_rsa_keygen_bits(ctx, 2048);
    EVP_PKEY* raw = nullptr;
    if (EVP_PKEY_keygen(ctx, &raw) <= 0)
        throw std::runtime_error("Key generation failed: " + openssl_error());
    EVP_PKEY_CTX_free(ctx);
    return EVP_PKEY_ptr(raw);
}

// Build a PKCS#10 CSR (DER) for the given SPIFFE ID, signed with the given key.
inline std::vector<uint8_t> build_csr(EVP_PKEY* key, const std::string& spiffe_uri) {
    X509_REQ_ptr req(X509_REQ_new());
    X509_REQ_set_version(req.get(), 0);
    X509_REQ_set_pubkey(req.get(), key);

    // Add the SAN with the SPIFFE URI
    X509_EXTENSIONS* exts = sk_X509_EXTENSION_new_null();
    std::string san_val   = "URI:" + spiffe_uri;
    X509_EXTENSION* ext = X509V3_EXT_conf_nid(
        nullptr, nullptr, NID_subject_alt_name, san_val.c_str());
    if (!ext) throw std::runtime_error("SAN extension failed: " + openssl_error());
    sk_X509_EXTENSION_push(exts, ext);
    X509_REQ_add_extensions(req.get(), exts);
    sk_X509_EXTENSION_pop_free(exts, X509_EXTENSION_free);

    if (X509_REQ_sign(req.get(), key, EVP_sha256()) <= 0)
        throw std::runtime_error("CSR sign failed: " + openssl_error());

    unsigned char* der = nullptr;
    int len = i2d_X509_REQ(req.get(), &der);
    if (len < 0) throw std::runtime_error("CSR DER encode failed: " + openssl_error());
    std::vector<uint8_t> out(der, der + len);
    OPENSSL_free(der);
    return out;
}

// Sign arbitrary bytes with the given key (SHA-256 + RSA/ECDSA).
inline std::vector<uint8_t> sign(EVP_PKEY* key,
                                  const uint8_t* data, size_t data_len) {
    EVP_MD_CTX* ctx = EVP_MD_CTX_new();
    if (!ctx) throw std::runtime_error("EVP_MD_CTX_new failed");

    if (EVP_DigestSignInit(ctx, nullptr, EVP_sha256(), nullptr, key) <= 0)
        throw std::runtime_error("DigestSignInit failed: " + openssl_error());
    if (EVP_DigestSignUpdate(ctx, data, data_len) <= 0)
        throw std::runtime_error("DigestSignUpdate failed: " + openssl_error());

    size_t sig_len = 0;
    EVP_DigestSignFinal(ctx, nullptr, &sig_len);
    std::vector<uint8_t> sig(sig_len);
    if (EVP_DigestSignFinal(ctx, sig.data(), &sig_len) <= 0)
        throw std::runtime_error("DigestSignFinal failed: " + openssl_error());
    sig.resize(sig_len);
    EVP_MD_CTX_free(ctx);
    return sig;
}

} // namespace crypto
} // namespace spire_agent
