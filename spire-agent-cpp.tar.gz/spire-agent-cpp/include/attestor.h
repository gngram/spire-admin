#pragma once
#include <memory>
#include <string>

#include <grpcpp/grpcpp.h>

#include "config.h"
#include "crypto_utils.h"
#include "logger.h"
#include "svid_store.h"

// Generated protobuf headers (included after build)
#include "spire/api/server/agent/v1/agent.grpc.pb.h"
#include "spire/api/server/agent/v1/agent.pb.h"

namespace spire_agent {

// X509PopAttestor carries out the x509pop attestation handshake against
// the SPIRE server's Agent API.
//
// Protocol (bidirectional streaming AttestAgent RPC):
//   1. Agent → Server : AttestAgentRequest{ params{ data{type="x509pop", payload=DER_cert}, csr } }
//   2. Server → Agent : AttestAgentResponse{ challenge{ nonce } }
//   3. Agent → Server : AttestAgentRequest{ challenge_response{ sign(nonce) } }
//   4. Server → Agent : AttestAgentResponse{ result{ svid, bundle, selectors } }
class X509PopAttestor {
public:
    X509PopAttestor(const Config& cfg, SVIDStore& store)
        : cfg_(cfg), store_(store) {}

    // Performs the full attestation handshake.
    // On success, populates store_ with the agent SVID and bundle.
    // On failure, throws std::runtime_error.
    void attest();

    // Renews the agent SVID by sending a new CSR over mTLS using the
    // current SVID as the client certificate.
    void renew();

private:
    const Config& cfg_;
    SVIDStore&    store_;

    // Build a gRPC channel to the SPIRE server.
    // During initial attestation (no SVID yet) → insecure / server-auth TLS.
    // During renewal → mTLS using the current SVID.
    std::shared_ptr<grpc::Channel> make_channel(bool use_svid_mtls = false);

    // Parse the server's AttestAgentResponse_Result and populate store_.
    void apply_result(
        const spire::api::server::agent::v1::AttestAgentResponse_Result& result,
        const crypto::EVP_PKEY_ptr& agent_key);
};

} // namespace spire_agent
