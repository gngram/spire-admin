# SPIRE Agent — C++ / x509pop

A minimal SPIRE agent written in C++ that implements **x509pop** (X.509 Proof of Possession) node attestation and exposes the **SPIFFE Workload API** over a Unix domain socket.

---

## Architecture

```
┌─────────────────────────────────────────────┐
│              spire_agent process             │
│                                             │
│  ┌────────────┐    ┌─────────────────────┐  │
│  │  Agent     │    │  WorkloadAPIServer  │  │
│  │ (main loop)│    │  (gRPC, Unix sock)  │  │
│  └─────┬──────┘    └──────────┬──────────┘  │
│        │                      │             │
│  ┌─────▼──────┐    ┌──────────▼──────────┐  │
│  │X509Pop     │    │     SVIDStore       │  │
│  │Attestor    │───▶│  (thread-safe SVID  │  │
│  │            │    │   + Bundle cache)   │  │
│  └────────────┘    └─────────────────────┘  │
└─────────────────────────────────────────────┘
        │ gRPC (TLS / mTLS)        │ Unix socket
        ▼                          ▼
  SPIRE Server              Workload processes
```

### Components

| Component | File | Responsibility |
|---|---|---|
| `Agent` | `agent.cpp` | Orchestrates attestation, workload API, renewal loop |
| `X509PopAttestor` | `attestor.cpp` | x509pop handshake + SVID renewal |
| `WorkloadAPIServer` | `workload_api.cpp` | SPIFFE Workload API (FetchX509SVID / FetchX509Bundles) |
| `SVIDStore` | `svid_store.h` | Thread-safe SVID + bundle store with pub/sub |
| `crypto::*` | `crypto_utils.h` | OpenSSL wrappers: key gen, CSR, sign, PEM↔DER |

---

## x509pop Attestation Flow

```
Agent                                   SPIRE Server
  │                                           │
  │──AttestAgent { params {                   │
  │     data { type="x509pop",                │
  │            payload=<DER cert> },          │
  │     csr=<PKCS#10 DER>                     │
  │   } }────────────────────────────────────▶│
  │                                           │ verify cert is trusted
  │◀─ AttestAgentResponse { challenge{nonce} }│
  │                                           │
  │  sign(nonce, attest_private_key)          │
  │──AttestAgentRequest {                     │
  │     challenge_response { sig } }─────────▶│
  │                                           │ verify signature
  │◀─ AttestAgentResponse { result {          │
  │      svid, bundle, selectors } }          │
  │                                           │
  │  store SVID + bundle                      │
  │  start Workload API                       │
  │  schedule renewal                         │
```

---

## Prerequisites

```bash
# Ubuntu/Debian
sudo apt install -y \
    cmake ninja-build \
    libgrpc++-dev libprotobuf-dev protobuf-compiler-grpc \
    libssl-dev \
    libabsl-dev
```

---

## Build

```bash
mkdir build && cd build
cmake .. -G Ninja -DCMAKE_BUILD_TYPE=Release
ninja
```

The binary is at `build/spire_agent`.

---

## SPIRE Server Setup

### 1. Configure x509pop on the server

Add to your `server.conf`:

```hcl
NodeAttestor "x509pop" {
    plugin_data {
        ca_bundle_path = "/etc/spire/server/agent-ca.pem"
    }
}
```

The CA that signed your agent cert must be in `agent-ca.pem`.

### 2. Generate an agent certificate

```bash
# Generate agent key
openssl genrsa -out agent.key.pem 2048

# Self-signed (for testing; in production sign with your CA)
openssl req -new -x509 -key agent.key.pem \
    -out agent.crt.pem -days 365 \
    -subj "/CN=spire-agent" \
    -addext "subjectAltName=URI:spiffe://example.org/spire/agent/x509pop/test"

# Register the cert fingerprint with the server
spire-server agent create \
    -spiffeID spiffe://example.org/spire/agent/x509pop/test \
    -selector x509pop:fingerprint:$(openssl x509 -in agent.crt.pem -fingerprint -sha256 -noout | cut -d= -f2 | tr -d ':' | tr '[:upper:]' '[:lower:]')
```

---

## Run

```bash
export SPIRE_SERVER_ADDRESS=localhost:8081
export SPIRE_TRUST_DOMAIN=example.org
export SPIRE_X509POP_CERT=/etc/spire/agent/agent.crt.pem
export SPIRE_X509POP_KEY=/etc/spire/agent/agent.key.pem
export SPIRE_WORKLOAD_SOCKET=/tmp/spire-agent/public/api.sock
export SPIRE_DATA_DIR=/var/lib/spire-agent

mkdir -p /tmp/spire-agent/public
./build/spire_agent
```

---

## Workload API

Workloads connect to `$SPIRE_WORKLOAD_SOCKET` and call the SPIFFE Workload API:

```bash
# Verify using the grpc_cli tool
grpc_cli call unix:/tmp/spire-agent/public/api.sock \
    spiffe.workload.SpiffeWorkloadAPI.FetchX509SVID \
    "" \
    --channel_creds_type=insecure
```

Or use any SPIFFE SDK (`go-spiffe`, `java-spiffe`, `py-spiffe`, etc.) — they all speak the same Workload API.

---

## What's NOT implemented (production gaps)

| Gap | Notes |
|---|---|
| Workload attestation | Real agents verify caller UID/GID/PID via Unix peer credentials; this agent trusts anyone on the socket |
| SVID disk persistence | SVIDs are in-memory only; a restart triggers re-attestation |
| JWT SVIDs | Only X.509 SVIDs are implemented |
| Federation | FederatesWithBundles not wired |
| Config file | Config is env-vars only; add JSON/YAML parsing for production |
