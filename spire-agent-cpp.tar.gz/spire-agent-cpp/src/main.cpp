#include <csignal>
#include <cstdlib>
#include <iostream>
#include <stdexcept>
#include <string>

#include "agent.h"
#include "config.h"
#include "logger.h"

// ── Global agent pointer for signal handler ───────────────────────────────────
static spire_agent::Agent* g_agent = nullptr;

static void signal_handler(int /*sig*/) {
    std::cout << "\nShutting down...\n";
    if (g_agent) g_agent->stop();
}

// ── Simple env-variable config loader ─────────────────────────────────────────
// In production you'd parse JSON/YAML; env vars keep this example portable.
static spire_agent::Config load_config() {
    auto getenv_or = [](const char* key, const char* def) -> std::string {
        const char* v = std::getenv(key);
        return v ? v : def;
    };

    spire_agent::Config cfg;
    cfg.server_address      = getenv_or("SPIRE_SERVER_ADDRESS",  "localhost:8081");
    cfg.trust_domain        = getenv_or("SPIRE_TRUST_DOMAIN",    "example.org");
    cfg.x509pop_cert_path   = getenv_or("SPIRE_X509POP_CERT",    "/etc/spire/agent/agent.crt.pem");
    cfg.x509pop_key_path    = getenv_or("SPIRE_X509POP_KEY",     "/etc/spire/agent/agent.key.pem");
    cfg.workload_api_socket = getenv_or("SPIRE_WORKLOAD_SOCKET", "/tmp/spire-agent/public/api.sock");
    cfg.data_dir            = getenv_or("SPIRE_DATA_DIR",        "/var/lib/spire-agent");
    cfg.renew_before_seconds = std::stoi(
        getenv_or("SPIRE_RENEW_BEFORE_SECONDS", "30"));
    return cfg;
}

int main(int argc, char* argv[]) {
    // Allow --help
    for (int i = 1; i < argc; ++i) {
        if (std::string(argv[i]) == "--help" || std::string(argv[i]) == "-h") {
            std::cout <<
                "SPIRE Agent (C++, x509pop)\n\n"
                "Configuration via environment variables:\n"
                "  SPIRE_SERVER_ADDRESS      SPIRE server host:port        (default: localhost:8081)\n"
                "  SPIRE_TRUST_DOMAIN        Trust domain                  (default: example.org)\n"
                "  SPIRE_X509POP_CERT        Path to attesting cert (PEM)  (default: /etc/spire/agent/agent.crt.pem)\n"
                "  SPIRE_X509POP_KEY         Path to attesting key  (PEM)  (default: /etc/spire/agent/agent.key.pem)\n"
                "  SPIRE_WORKLOAD_SOCKET     Workload API Unix socket path (default: /tmp/spire-agent/public/api.sock)\n"
                "  SPIRE_DATA_DIR            Agent data directory          (default: /var/lib/spire-agent)\n"
                "  SPIRE_RENEW_BEFORE_SECONDS Renewal lead time in seconds  (default: 30)\n";
            return 0;
        }
    }

    std::signal(SIGINT,  signal_handler);
    std::signal(SIGTERM, signal_handler);

    try {
        auto cfg = load_config();

        LOG_INFO("main", "SPIRE C++ Agent starting");
        LOG_INFO("main", "  server:        " + cfg.server_address);
        LOG_INFO("main", "  trust_domain:  " + cfg.trust_domain);
        LOG_INFO("main", "  cert:          " + cfg.x509pop_cert_path);
        LOG_INFO("main", "  workload sock: " + cfg.workload_api_socket);

        spire_agent::Agent agent(cfg);
        g_agent = &agent;
        agent.run();

    } catch (const std::exception& e) {
        LOG_ERROR("main", std::string("Fatal: ") + e.what());
        return 1;
    }

    return 0;
}
