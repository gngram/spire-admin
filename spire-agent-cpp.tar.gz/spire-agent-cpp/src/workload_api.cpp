#include "workload_api.h"

#include <condition_variable>
#include <mutex>
#include <thread>

#include <grpcpp/grpcpp.h>

namespace spire_agent {

// ── Response builders ─────────────────────────────────────────────────────────

spiffe::workload::X509SVIDResponse
WorkloadAPIServer::build_svid_response() const {
    spiffe::workload::X509SVIDResponse resp;
    if (!store_.has_svid()) return resp;

    SVID svid     = store_.get_svid();
    Bundle bundle = store_.get_bundle();

    auto* entry = resp.add_svids();
    entry->set_spiffe_id(svid.spiffe_id);

    // cert chain: all certs concatenated (DER per element)
    std::string chain_der;
    for (auto& cert : svid.cert_chain)
        chain_der.append(reinterpret_cast<const char*>(cert.data()), cert.size());
    entry->set_x509_svid(chain_der);

    // private key
    entry->set_x509_svid_key(
        std::string(svid.private_key_der.begin(), svid.private_key_der.end()));

    // bundle (trust domain root certs, concatenated DER)
    std::string bundle_der;
    for (auto& root : bundle.x509_authorities)
        bundle_der.append(reinterpret_cast<const char*>(root.data()), root.size());
    entry->set_bundle(bundle_der);

    return resp;
}

spiffe::workload::X509BundlesResponse
WorkloadAPIServer::build_bundles_response() const {
    spiffe::workload::X509BundlesResponse resp;
    if (!store_.has_bundle()) return resp;

    Bundle bundle = store_.get_bundle();
    std::string bundle_der;
    for (auto& root : bundle.x509_authorities)
        bundle_der.append(reinterpret_cast<const char*>(root.data()), root.size());

    (*resp.mutable_bundles())[bundle.trust_domain] = bundle_der;
    return resp;
}

// ── RPC implementations ───────────────────────────────────────────────────────

grpc::Status WorkloadAPIServer::FetchX509SVID(
    grpc::ServerContext*                               ctx,
    const spiffe::workload::X509SVIDRequest*           /*req*/,
    grpc::ServerWriter<spiffe::workload::X509SVIDResponse>* writer)
{
    LOG_INFO("workload-api", "FetchX509SVID called");

    // Condition variable so the renewal loop can wake up streaming RPCs.
    std::mutex              mu;
    std::condition_variable cv;
    bool                    updated = false;

    // Subscribe to SVID updates.
    store_.on_update([&] {
        std::lock_guard<std::mutex> lk(mu);
        updated = true;
        cv.notify_all();
    });

    // Send the current SVID immediately.
    while (!store_.has_svid()) {
        LOG_DEBUG("workload-api", "Waiting for first SVID...");
        std::this_thread::sleep_for(std::chrono::milliseconds(200));
        if (ctx->IsCancelled()) return grpc::Status::CANCELLED;
    }

    auto resp = build_svid_response();
    if (!writer->Write(resp)) return grpc::Status::OK;

    // Then stream updates until the client disconnects.
    while (!ctx->IsCancelled()) {
        std::unique_lock<std::mutex> lk(mu);
        cv.wait_for(lk, std::chrono::seconds(5), [&] { return updated; });

        if (ctx->IsCancelled()) break;

        if (updated) {
            updated = false;
            lk.unlock();
            auto update = build_svid_response();
            if (!writer->Write(update)) break;
            LOG_DEBUG("workload-api", "Sent SVID update to subscriber");
        }
    }

    return grpc::Status::OK;
}

grpc::Status WorkloadAPIServer::FetchX509Bundles(
    grpc::ServerContext*                                ctx,
    const spiffe::workload::X509BundlesRequest*        /*req*/,
    grpc::ServerWriter<spiffe::workload::X509BundlesResponse>* writer)
{
    LOG_INFO("workload-api", "FetchX509Bundles called");

    std::mutex              mu;
    std::condition_variable cv;
    bool                    updated = false;

    store_.on_update([&] {
        std::lock_guard<std::mutex> lk(mu);
        updated = true;
        cv.notify_all();
    });

    while (!store_.has_bundle()) {
        std::this_thread::sleep_for(std::chrono::milliseconds(200));
        if (ctx->IsCancelled()) return grpc::Status::CANCELLED;
    }

    auto resp = build_bundles_response();
    if (!writer->Write(resp)) return grpc::Status::OK;

    while (!ctx->IsCancelled()) {
        std::unique_lock<std::mutex> lk(mu);
        cv.wait_for(lk, std::chrono::seconds(5), [&] { return updated; });
        if (ctx->IsCancelled()) break;
        if (updated) {
            updated = false;
            lk.unlock();
            if (!writer->Write(build_bundles_response())) break;
        }
    }

    return grpc::Status::OK;
}

// ── Lifecycle ─────────────────────────────────────────────────────────────────

void WorkloadAPIServer::start() {
    std::string addr = "unix:" + cfg_.workload_api_socket;

    grpc::ServerBuilder builder;
    builder.AddListeningPort(addr, grpc::InsecureServerCredentials());
    builder.RegisterService(this);
    server_ = builder.BuildAndStart();

    if (!server_)
        throw std::runtime_error("Failed to start Workload API server on " + addr);

    LOG_INFO("workload-api", "Workload API listening on " + addr);

    server_thread_ = std::thread([this] { server_->Wait(); });
}

void WorkloadAPIServer::stop() {
    if (server_) {
        server_->Shutdown();
        if (server_thread_.joinable()) server_thread_.join();
    }
}

} // namespace spire_agent
