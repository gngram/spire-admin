#include "attestor.h"

#include <stdexcept>
#include <string>

#include <openssl/evp.h>
#include <openssl/x509.h>

#include <grpcpp/grpcpp.h>

#include "spire/api/server/agent/v1/agent.grpc.pb.h"
#include "spire/api/server/agent/v1/agent.pb.h"

namespace spire_agent {

using namespace spire::api::server::agent::v1;

// ── Channel factory ───────────────────────────────────────────────────────────

std::shared_ptr<grpc::Channel> X509PopAttestor::make_channel(bool use_svid_mtls) {
    if (!use_svid_mtls) {
        // Plain TLS — verify server certificate but no client cert yet.
        auto creds = grpc::SslCredentials(grpc::SslCredentialsOptions{});
        return grpc::CreateChannel(cfg_.server_address, creds);
    }

    // mTLS using the current SVID as the client certificate.
    SVID svid = store_.get_svid();
    Bundle bundle = store_.get_bundle();

    // Flatten cert chain to PEM for gRPC SSL credentials.
    // gRPC needs PEM strings; convert DER → PEM via OpenSSL.
    auto der_to_pem_cert = [](const std::vector<uint8_t>& der) -> std::string {
        const unsigned char* p = der.data();
        crypto::X509_ptr cert(d2i_X509(nullptr, &p, der.size()));
        if (!cert) throw std::runtime_error("DER→X509 failed");
        crypto::BIO_ptr bio(BIO_new(BIO_s_mem()));
        PEM_write_bio_X509(bio.get(), cert.get());
        char* buf; long len = BIO_get_mem_data(bio.get(), &buf);
        return std::string(buf, len);
    };

    auto der_to_pem_key = [](const std::vector<uint8_t>& der) -> std::string {
        const unsigned char* p = der.data();
        crypto::EVP_PKEY_ptr key(d2i_AutoPrivateKey(nullptr, &p, der.size()));
        if (!key) throw std::runtime_error("DER→PKEY failed");
        crypto::BIO_ptr bio(BIO_new(BIO_s_mem()));
        PEM_write_bio_PrivateKey(bio.get(), key.get(), nullptr, nullptr, 0, nullptr, nullptr);
        char* buf; long len = BIO_get_mem_data(bio.get(), &buf);
        return std::string(buf, len);
    };

    std::string cert_chain_pem;
    for (auto& der : svid.cert_chain) cert_chain_pem += der_to_pem_cert(der);

    std::string key_pem = der_to_pem_key(svid.private_key_der);

    std::string root_pem;
    for (auto& der : bundle.x509_authorities) root_pem += der_to_pem_cert(der);

    grpc::SslCredentialsOptions opts;
    opts.pem_cert_chain      = cert_chain_pem;
    opts.pem_private_key     = key_pem;
    opts.pem_root_certs      = root_pem;

    return grpc::CreateChannel(cfg_.server_address, grpc::SslCredentials(opts));
}

// ── Result application ────────────────────────────────────────────────────────

void X509PopAttestor::apply_result(
    const AttestAgentResponse_Result& result,
    const crypto::EVP_PKEY_ptr& agent_key)
{
    SVID svid;
    svid.spiffe_id = "spiffe://" + result.svid().id().trust_domain()
                   + result.svid().id().path();
    svid.expires_at = result.svid().expires_at();

    for (auto& der_str : result.svid().cert_chain())
        svid.cert_chain.push_back(
            std::vector<uint8_t>(der_str.begin(), der_str.end()));

    // Serialize the ephemeral private key as PKCS#8 DER for storage.
    crypto::BIO_ptr bio(BIO_new(BIO_s_mem()));
    i2d_PKCS8PrivateKey_bio(bio.get(), agent_key.get(), nullptr,
                             nullptr, 0, nullptr, nullptr);
    char* buf; long len = BIO_get_mem_data(bio.get(), &buf);
    svid.private_key_der = std::vector<uint8_t>(buf, buf + len);

    store_.set_svid(svid);

    // Store the trust bundle.
    Bundle bundle;
    bundle.trust_domain = result.bundle().trust_domain();
    for (auto& auth : result.bundle().x509_authorities())
        bundle.x509_authorities.push_back(
            std::vector<uint8_t>(auth.asn1().begin(), auth.asn1().end()));

    store_.set_bundle(bundle);

    LOG_INFO("attestor",
        "SVID stored: " + svid.spiffe_id +
        " (expires in " +
        std::to_string(svid.seconds_until_expiry()) + "s)");
}

// ── Attestation ───────────────────────────────────────────────────────────────

void X509PopAttestor::attest() {
    LOG_INFO("attestor", "Starting x509pop attestation");

    // 1. Load the attesting certificate (the node identity cert).
    auto cert_der  = crypto::load_cert_der(cfg_.x509pop_cert_path);
    auto attest_key = crypto::load_private_key(cfg_.x509pop_key_path);

    // 2. Generate a fresh ephemeral key pair for the agent SVID.
    auto agent_key = crypto::generate_key();

    // 3. Build a SPIFFE ID for the CSR.
    //    For x509pop the server derives the SPIFFE ID from the cert's SAN,
    //    but the CSR still needs *a* SAN; use the trust domain root.
    std::string spiffe_uri = "spiffe://" + cfg_.trust_domain + "/spire/agent/x509pop";
    // (The server will override this based on the cert CN/SAN mapping.)
    auto csr = crypto::build_csr(agent_key.get(), spiffe_uri);

    // 4. Open the streaming RPC.
    auto channel = make_channel(/*use_svid_mtls=*/false);
    auto stub    = Agent::NewStub(channel);

    grpc::ClientContext ctx;
    auto stream = stub->AttestAgent(&ctx);

    // 5. Send the initial params message.
    AttestAgentRequest req;
    auto* params = req.mutable_params();
    params->mutable_data()->set_type("x509pop");
    params->mutable_data()->set_payload(
        std::string(cert_der.begin(), cert_der.end()));
    params->set_params(std::string(csr.begin(), csr.end()));

    if (!stream->Write(req))
        throw std::runtime_error("AttestAgent: failed to send params");

    LOG_DEBUG("attestor", "Sent attestation params (cert DER + CSR)");

    // 6. Read the server's challenge.
    AttestAgentResponse resp;
    if (!stream->Read(&resp))
        throw std::runtime_error("AttestAgent: no response from server");

    if (!resp.has_challenge())
        throw std::runtime_error("AttestAgent: expected challenge, got result");

    const std::string& nonce = resp.challenge().challenge();
    LOG_DEBUG("attestor", "Received challenge (" + std::to_string(nonce.size()) + " bytes)");

    // 7. Sign the nonce with the attesting private key and send the response.
    auto sig = crypto::sign(attest_key.get(),
        reinterpret_cast<const uint8_t*>(nonce.data()), nonce.size());

    AttestAgentRequest cr;
    cr.mutable_challenge_response()->set_response(
        std::string(sig.begin(), sig.end()));

    if (!stream->Write(cr))
        throw std::runtime_error("AttestAgent: failed to send challenge response");

    LOG_DEBUG("attestor", "Sent challenge response (signed nonce)");

    // 8. Read the final result.
    if (!stream->Read(&resp))
        throw std::runtime_error("AttestAgent: no result after challenge response");

    if (!resp.has_result())
        throw std::runtime_error("AttestAgent: expected result, got challenge again");

    stream->WritesDone();
    auto status = stream->Finish();
    if (!status.ok())
        throw std::runtime_error("AttestAgent RPC failed: " + status.error_message());

    apply_result(resp.result(), agent_key);
    LOG_INFO("attestor", "Attestation complete");
}

// ── Renewal ───────────────────────────────────────────────────────────────────

void X509PopAttestor::renew() {
    LOG_INFO("attestor", "Renewing agent SVID");

    auto agent_key = crypto::generate_key();
    std::string spiffe_id = store_.get_svid().spiffe_id;
    auto csr = crypto::build_csr(agent_key.get(), spiffe_id);

    auto channel = make_channel(/*use_svid_mtls=*/true);
    auto stub    = Agent::NewStub(channel);

    grpc::ClientContext ctx;
    RenewAgentRequest req;
    req.set_params(std::string(csr.begin(), csr.end()));

    RenewAgentResponse resp;
    auto status = stub->RenewAgent(&ctx, req, &resp);
    if (!status.ok())
        throw std::runtime_error("RenewAgent RPC failed: " + status.error_message());

    SVID svid = store_.get_svid(); // keep existing fields
    svid.expires_at = resp.svid().expires_at();
    svid.cert_chain.clear();
    for (auto& der_str : resp.svid().cert_chain())
        svid.cert_chain.push_back(
            std::vector<uint8_t>(der_str.begin(), der_str.end()));

    // Persist new private key.
    crypto::BIO_ptr bio(BIO_new(BIO_s_mem()));
    i2d_PKCS8PrivateKey_bio(bio.get(), agent_key.get(), nullptr,
                             nullptr, 0, nullptr, nullptr);
    char* buf; long len = BIO_get_mem_data(bio.get(), &buf);
    svid.private_key_der = std::vector<uint8_t>(buf, buf + len);

    store_.set_svid(svid);
    store_.notify_update();

    LOG_INFO("attestor",
        "SVID renewed (expires in " +
        std::to_string(svid.seconds_until_expiry()) + "s)");
}

} // namespace spire_agent
