#include "agent.h"

#include <chrono>
#include <stdexcept>
#include <thread>

#include "logger.h"

namespace spire_agent {

Agent::Agent(const Config& cfg)
    : cfg_(cfg),
      attestor_(std::make_unique<X509PopAttestor>(cfg_, store_)),
      workload_server_(std::make_unique<WorkloadAPIServer>(cfg_, store_))
{}

void Agent::run() {
    running_ = true;

    // ── Step 1: Attest ───────────────────────────────────────────────────────
    // Retry attestation on transient failures (e.g. server not yet up).
    int attest_attempts = 0;
    while (running_) {
        try {
            attestor_->attest();
            break;
        } catch (const std::exception& e) {
            ++attest_attempts;
            LOG_ERROR("agent", std::string("Attestation failed (attempt ") +
                      std::to_string(attest_attempts) + "): " + e.what());
            if (attest_attempts >= 5)
                throw std::runtime_error("Attestation failed after 5 attempts");
            std::this_thread::sleep_for(std::chrono::seconds(5));
        }
    }

    // ── Step 2: Start Workload API ───────────────────────────────────────────
    workload_server_->start();

    // ── Step 3: Renewal loop ─────────────────────────────────────────────────
    renewal_thread_ = std::thread([this] { renewal_loop(); });

    LOG_INFO("agent", "Agent running. Press Ctrl-C to stop.");
    renewal_thread_.join();
}

void Agent::stop() {
    running_ = false;
    workload_server_->stop();
    if (renewal_thread_.joinable()) renewal_thread_.join();
}

void Agent::renewal_loop() {
    while (running_) {
        SVID svid = store_.get_svid();
        int64_t ttl = svid.seconds_until_expiry();

        // Wake up `renew_before_seconds` before expiry.
        int64_t sleep_secs = ttl - cfg_.renew_before_seconds;

        if (sleep_secs <= 0) {
            // Expired or about to expire — renew immediately.
            LOG_WARN("agent", "SVID expiring soon, renewing now");
        } else {
            LOG_INFO("agent",
                "SVID valid for " + std::to_string(ttl) + "s, "
                "renewing in " + std::to_string(sleep_secs) + "s");

            // Sleep in small chunks so we can respond to stop() promptly.
            for (int64_t i = 0; i < sleep_secs && running_; ++i)
                std::this_thread::sleep_for(std::chrono::seconds(1));
        }

        if (!running_) break;

        try {
            attestor_->renew();
            store_.notify_update(); // push new SVID to Workload API subscribers
        } catch (const std::exception& e) {
            LOG_ERROR("agent", std::string("SVID renewal failed: ") + e.what());
            // Back off and retry soon.
            std::this_thread::sleep_for(std::chrono::seconds(10));
        }
    }

    LOG_INFO("agent", "Renewal loop exiting");
}

} // namespace spire_agent
